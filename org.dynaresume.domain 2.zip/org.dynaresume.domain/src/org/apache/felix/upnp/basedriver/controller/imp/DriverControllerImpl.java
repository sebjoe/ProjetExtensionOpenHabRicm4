package org.apache.felix.upnp.basedriver.controller.imp;

import org.apache.felix.upnp.basedriver.controller.DevicesInfo;
import org.apache.felix.upnp.basedriver.controller.DriverController;

public class DriverControllerImpl implements DriverController, DevicesInfo{

	public String getLocationURL(String udn) {
		// TODO Auto-generated method stub
		return udn;
	}

	public String getSCPDURL(String udn, String serviceId) {
		// TODO Auto-generated method stub
		return udn+serviceId;
	}

	public String resolveRelativeUrl(String udn, String link) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setLogLevel(int n) {
		// TODO Auto-generated method stub
		
	}

	public int getLogLevel() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setCyberDebug(boolean b) {
		// TODO Auto-generated method stub
		
	}

	public boolean getCyberDebug() {
		// TODO Auto-generated method stub
		return false;
	}

	public void search(String target) {
		// TODO Auto-generated method stub
		
	}

}
